# VisionCraft AR Marketplace

**Flask-based AR e-commerce platform** for artisan crafts with WebXR 3D model viewing, authentication, cart/checkout, seller analytics, and events.

## Tech Stack
- **Backend:** Flask 3.0, Flask-Login, Flask-SQLAlchemy, SQLite
- **Frontend:** Jinja2, vanilla JS/CSS, Google Model Viewer (WebXR)
- **AR:** GLB/GLTF 3D models with WebXR/Scene Viewer/Quick Look

## Quick Start

```powershell
# 1. Setup environment
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt

# 2. Initialize database
python init_db.py

# 3. Run application
python app.py
# Open http://localhost:5000
```

### Sample Accounts
| Role | Username | Password |
|------|----------|----------|
| Customer | demo_customer | password123 |
| Customer | art_lover | password123 |
| Seller | sanjay_potter | seller123 |
| Seller | priya_woodcraft | seller123 |
| Seller | lakshmi_painter | seller123 |

## Project Structure

```
VisionCraft/
├── app.py              # Main Flask app & routes
├── models.py           # SQLAlchemy models (User, Artwork, Order, etc.)
├── init_db.py          # Database seeder
├── check_assets.py     # Asset verification tool
├── requirements.txt    # Python dependencies
├── templates/          # Jinja2 HTML templates
├── static/
│   ├── images/         # Product images
│   ├── models/         # 3D GLB/GLTF files
│   ├── avatars/        # User avatars
│   ├── style.css
│   └── toast.js
└── instance/
    └── visioncraft.db  # SQLite database (generated)
```

## Core Features

### Authentication & Users
- Registration/login with Flask-Login
- Role-based access (customer/seller)
- Profile management with avatar upload
- Password hashing (Werkzeug)

### Product Catalog
- Browse artworks with filters (category, state)
- Sort by price/rating/likes
- Search by title/artist/description/category
- AR preview with `<model-viewer>`
- View count tracking

### Shopping
- Cart management (add/update/remove)
- Checkout with shipping details
- Order confirmation & history
- Fixed shipping fee (₹149)
- Payment methods: COD, UPI

### Seller Tools
- Upload artwork with image/3D model
- Analytics dashboard (views, likes, AR tries, revenue)
- Edit/delete own artworks
- Stock management

### Community
- Like/favorite artworks
- Events & workshops calendar
- RSVP functionality
- Interactive crafts map
- AR wall stylist

### UX
- Mobile-first responsive design
- Dark/light theme toggle
- English/Hindi language switch
- Toast notifications

## Data Models

```python
User (id, username, email, password_hash, role, bio, phone, location, avatar)
  └── relationships: artworks, orders, cart_items, likes, rsvps

Artwork (id, title, description, price, category, image, model_url, 
         artist_name, state, stock_quantity, views, rating, is_active)
  └── relationships: likes, cart_items, order_items

CartItem (id, user_id, artwork_id, quantity)
Order (id, order_number, user_id, status, payment_method, total_amount, shipping_*)
OrderItem (id, order_id, artwork_id, artwork_title, artwork_price, quantity, subtotal)
Like (id, user_id, artwork_id) [unique constraint]
Event (id, title, description, event_type, event_date, event_time, location, tags)
EventRSVP (id, user_id, event_id) [unique constraint]
```

## API Endpoints

### Public Routes
```
GET  /                     # Landing page
GET  /home                 # Gallery with filters
GET  /art/<id>             # Artwork detail
GET  /ar/<id>              # AR viewer
GET  /search?q=            # Search
GET  /events               # Events list
GET  /crafts-map           # Interactive map
GET  /wall-stylist         # AR wall tool
```

### Authentication
```
GET/POST /register         # Create account
GET/POST /login            # Login
GET      /logout           # Logout (auth required)
```

### Cart & Orders (auth required)
```
GET    /cart                           # View cart
POST   /api/cart/add/<art_id>          # Add to cart → {success, cart_count}
POST   /api/cart/update/<item_id>      # Update quantity → {success, cart_count}
DELETE /api/cart/remove/<item_id>      # Remove item → {success, cart_count}
GET    /checkout                       # Checkout page
POST   /checkout/process               # Create order
GET    /order/<id>                     # Order confirmation
GET    /orders                         # Order history
```

### Likes (auth required)
```
GET  /likes                      # Liked artworks
POST /api/toggle_like/<art_id>  # Toggle like → {success, liked, likes_count}
```

### Profile (auth required)
```
GET  /profile           # Profile page
POST /profile/update    # Update bio/phone/location
POST /profile/avatar    # Upload avatar → {success, avatar_url}
```

### Seller (auth + role required)
```
GET      /seller/analytics       # Dashboard
GET/POST /upload                 # Upload artwork
GET/POST /edit/<art_id>          # Edit artwork
DELETE   /api/delete_art/<art_id> # Soft delete → {success}
```

### Events
```
POST /api/events/rsvp/<event_id>  # Toggle RSVP → {success, rsvped}
```

## Configuration

**Environment Variables:**
```powershell
$env:SECRET_KEY = "your-secret-key-here"  # Default: random hex
$env:SQLALCHEMY_DATABASE_URI = "sqlite:///visioncraft.db"  # Default
```

**Upload Limits:**
- Max file size: 16 MB
- Allowed images: .png, .jpg, .jpeg, .gif, .webp
- Allowed models: .glb, .gltf

## Asset Management

**Check assets:**
```powershell
python check_assets.py
```

**Asset optimization tips:**
- Keep GLB files < 10 MB for fast AR loading
- Use Draco compression for meshes
- Optimize textures (power-of-2 sizes: 512/1024/2048)
- Ensure correct model scale (meters) for AR placement

## Deployment

### Linux (Gunicorn + Nginx)
```bash
pip install gunicorn
gunicorn -w 4 -b 127.0.0.1:8000 app:app
```

### Windows (Waitress)
```powershell
pip install waitress
waitress-serve --host=0.0.0.0 --port=8000 app:app
```

**Production checklist:**
- [ ] Use PostgreSQL instead of SQLite
- [ ] Set strong SECRET_KEY
- [ ] Enable HTTPS
- [ ] Configure secure session cookies
- [ ] Add CSRF protection (Flask-WTF)
- [ ] Implement rate limiting (Flask-Limiter)
- [ ] Add Alembic for migrations
- [ ] Set up error tracking (Sentry)
- [ ] Configure CDN for static assets
- [ ] Add backup strategy

## Troubleshooting

**Login fails after seeding:**
```powershell
# Re-run database initialization
Remove-Item instance/visioncraft.db
python init_db.py
```

**AR viewer blank:**
- Ensure artwork has `model_url` set to valid GLB file
- Test on WebXR-compatible device/browser
- Check browser console for loading errors

**Template errors (art.artist):**
- Model field is `artist_name`, not `artist`
- Update templates to use `{{ art.artist_name }}`

**Database locked (SQLite):**
- Close other processes accessing the DB
- Avoid concurrent writes (use PostgreSQL for production)

## Improvement Suggestions

### Security
- Add CSRF protection for all forms/APIs
- Set SESSION_COOKIE_SECURE, SESSION_COOKIE_HTTPONLY, SESSION_COOKIE_SAMESITE
- Validate MIME types on uploads (not just extensions)
- Implement password reset with email verification
- Add rate limiting on auth endpoints
- Configure Content Security Policy headers

### Performance
- Add database indexes: `category`, `created_at`, `state`
- Implement pagination for `/home`
- Eager load relationships to avoid N+1 queries
- Cache static assets with versioning
- Denormalize `likes_count` on Artwork model

### Code Quality
- Add pytest with fixtures for unit/integration tests
- Split `app.py` into blueprints (auth, catalog, cart, seller, events)
- Add pre-commit hooks (black, isort, flake8)
- Configure Alembic for database migrations
- Add type hints (mypy)

### DevEx
- Create `.env.example` with documented variables
- Add `manage.py` or Makefile for common tasks
- Containerize with Docker + docker-compose
- Add CI/CD pipeline (GitHub Actions)
- Set up automated testing and linting

### Features
- Add product reviews and ratings
- Implement email notifications for orders
- Add payment gateway integration
- Support multiple images per artwork
- Add seller inventory alerts
- Implement recommendation engine

## License

[Add your license here]

## Credits

- **Model Viewer:** Google (WebXR AR)
- **Icons:** Font Awesome
- **Fonts:** Google Fonts (Inter)

---

**Version:** 0.1.0 | **Updated:** 2025-10-14
